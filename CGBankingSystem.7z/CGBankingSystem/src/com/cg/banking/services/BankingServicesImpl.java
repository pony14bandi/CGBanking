package com.cg.banking.services;

import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class BankingServicesImpl implements BankingServices {
	private BankingDAOServices daoServices;

	public BankingServicesImpl() {
		daoServices = new BnakingDAOServicesImpl();
	}
}
